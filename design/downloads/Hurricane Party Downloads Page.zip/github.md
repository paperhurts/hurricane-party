repo: paperhurts/hurricane-party
branch: main

## Last sync
date: 2026-09-05T14:21:15Z

### Updated in this project
- Built the GitHub Pages downloads page from the README, tokens.json, theme.md and the release-exe workflow
- Copied the five capybara PNGs and the Main / EQ / Playlist prototype windows for live embeds

## Screen map
| Screen | Repo files |
|---|---|
| Downloads Page.dc.html | README.md, design/tokens.json, docs/theme.md, .github/workflows/release-exe.yml, design/icon/*.png |
| MainWindow.dc.html, EqWindow.dc.html, PlaylistWindow.dc.html | design/screens/ (same names) |
